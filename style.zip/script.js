let container_info_gl = document.querySelector('.container_info_gl')
let container_trey = document.querySelector('.container_trey')
let name_city = document.getElementById('name_city')
let info_city = document.getElementById('info_city')
let close_display_info = document.getElementById('close_display_info')


let Chukotka = document.querySelectorAll('.CHUKOTKA')
let Yakutia = document.querySelectorAll('.YAKUTIA')
let Krosnoyarsk = document.querySelectorAll('.KRASNOYARSK')
let Yamalonenezkii_ao = document.querySelectorAll('.YAMALONENEZKII_AO')
let Hantamansiiskiy_ao = document.querySelectorAll('.HANTAMANSIISKIY_AO')
let Irkutsk = document.querySelectorAll('.IRKUTSK')
let Amurskay_oblast = document.querySelectorAll('.AMURSKAY_OBLAST')
let Komi = document.querySelectorAll('.KOMI')
let Tayava = document.querySelectorAll('.TAYVA')
let Altay = document.querySelectorAll('.ALTAY')
let Tomskay_oblast = document.querySelectorAll('.TOMSKAY_OBLAST')
let Altaiskii_kray62 = document.querySelectorAll('.ALTAISKII_KRAY62')
let Arhangelskay_oblast1 = document.querySelectorAll('.ARHANGELSKAY_OBLAST1')
let Astrahanskay_oblast2 = document.querySelectorAll('.ASTRAHANSKAY_OBLAST2')
let Belgorodskay_oblast3 = document.querySelectorAll('.BELGORODSKAY_OBLAST3')
let Branskay_oblast4 = document.querySelectorAll('.BRANSKAY_OBLAST4')
let Vladimirskay5 = document.querySelectorAll('.VLADIMIRSKAY5')
let Volgogradsay_oblast6 = document.querySelectorAll('.VOLGOGRADSAY_OBLAST6')
let Vologodskay_oblast7 = document.querySelectorAll('.VOLOGODSKAY_OBLAST7')

let Voronechskay_oblast8 = document.querySelectorAll('.VORONECHSKAY_OBLAST8')
let Ivanovskay_oblast9 = document.querySelectorAll('.IVANOVSKAY_OBLAST9')
let Kaliningradskay_oblast10 = document.querySelectorAll('.KALININGRADSKAY_OBLAST10')
let Kalurchskay11 = document.querySelectorAll('.KALURCHSKAY11')
let Kemerovskay_oblast12 = document.querySelectorAll('.KEMEROVSKAY_OBLAST12')
let Kurganskay_oblast13 = document.querySelectorAll('.KURGANSKAY_OBLAST13')
let kostromskay_oblast14 = document.querySelectorAll('.KOSTROMSKAY_OBLAST14')
let Kurganskay_oblast15 = document.querySelectorAll('.KURGANSKAY_OBLAST15')
let Kyrskay_oblast16 = document.querySelectorAll('.KYRSKAY_OBLAST16')
let Leningradskay_oblast17 = document.querySelectorAll('.LENINGRADSKAY_OBLAST17')
let Lipezkay_oblast18 = document.querySelectorAll('.LIPEZKAY_OBLAST18')
let Magadanskay_oblast19 = document.querySelectorAll('.MAGADANSKAY_OBLAST19')
let Moskovskay_oblast20 = document.querySelectorAll('.MOSKOVSKAY_OBLAST20')
let Murmanskay_oblast21 = document.querySelectorAll('.MURMANSKAY_OBLAST21')
let Nichegorodskay_oblast22 = document.querySelectorAll('.NICHEGORODSKAY_OBLAST22')
let Novgorodskay_oblast23 = document.querySelectorAll('.NOVGORODSKAY_OBLAST23')
let Omskay_oblast24 = document.querySelectorAll('.OMSKAY_OBLAST24')
let Novosibirskay_oblast25 = document.querySelectorAll('.NOVOSIBIRSKAY_OBLAST25')
let Orenburgskay_oblast26 = document.querySelectorAll('.ORENBURGSKAY_OBLAST26')
let Orlovskay_oblast27 = document.querySelectorAll('.ORLOVSKAY_OBLAST27')
let Penzenskay_oblast28 = document.querySelectorAll('.PENZENSKAY_OBLAST28')
let Pskovskay_oblast29 = document.querySelectorAll('.PSKOVSKAY_OBLAST29')
let Rostovskay_oblast30 = document.querySelectorAll('.ROSTOVSKAY_OBLAST30')

let Ryzanskay_oblast31 = document.querySelectorAll('.RYZANSKAY_OBLAST31')
let Samarskay_oblast32 = document.querySelectorAll('.SAMARSKAY_OBLAST32')
let Saratovskay_oblast33 = document.querySelectorAll('.SARATOVSKAY_OBLAST33')
let Sahalinskay_oblast34 = document.querySelectorAll('.SAHALINSKAY_OBLAST34')
let Sverdlovskay_oblast35 = document.querySelectorAll('.SVERDLOVSKAY_OBLAST35')
let Smolenskay_oblast36 = document.querySelectorAll('.SMOLENSKAY_OBLAST36')
let Tambovskay_oblast37 = document.querySelectorAll('.TAMBOVSKAY_OBLAST37')
let Tverskay_oblast38 = document.querySelectorAll('.TVERSKAY_OBLAST38')
let Tulskay_oblast39 = document.querySelectorAll('.TULSKAY_OBLAST39')
let Tymenskay_oblast40 = document.querySelectorAll('.TYMENSKAY_OBLAST40')
let Ulaynovskay_oblast41 = document.querySelectorAll('.ULAYNOVSKAY_OBLAST41')
let Chelybinskay_oblast42 = document.querySelectorAll('.CHELYBINSKAY_OBLAST42')
let Yaroslavskay_oblast43 = document.querySelectorAll('.YAROSLAVSKAY_OBLAST43')
let Adageya44 = document.querySelectorAll('.ADAGEYA44')
let Bashkortostan45 = document.querySelectorAll('.BASHKORTOSTAN45')
let Burytiay46 = document.querySelectorAll('.BURYTIAY46')
let Dagestan47 = document.querySelectorAll('.DAGESTAN47')
let Ingushetia48 = document.querySelectorAll('.INGUSHETIA48')
let Kabardino49 = document.querySelectorAll('.KABARDINO49')
let Kalmkiy50 = document.querySelectorAll('.KALMKIY50')
let Karachaevo51 = document.querySelectorAll('.KARACHAEVO51')
let Kaleriy52 = document.querySelectorAll('.KALERIY52')
let Krym53 = document.querySelectorAll('.KRYM53')
let mariiyal54 = document.querySelectorAll('.MARIIYAL54')
let mordoviy55 = document.querySelectorAll('.MORDOVIY55')
let Osetiay56 = document.querySelectorAll('.OSETIAY56')
let Tatarstan57 = document.querySelectorAll('.TATARSTAN57')
let Udmurtskay58 = document.querySelectorAll('.UDMURTSKAY58')
let Hakasiy59 = document.querySelectorAll('.HAKASIY59')
let Chuvashskay60 = document.querySelectorAll('.CHUVASHSKAY60')
let Evreiskay_avtonomnay_oblast61 = document.querySelectorAll('.EVREISKAY_AVTONOMNAY_OBLAST61')
let Nenezkii_ao62 = document.querySelectorAll('.NENEZKII_AO62')
let Sevastopol63 = document.querySelectorAll('.SEVASTOPOL63')
let Kamchatskii_kray64 = document.querySelectorAll('.KAMCHATSKII_KRAY64')
let Krasnodarskii65 = document.querySelectorAll('.KRASNODARSKII65')
let Permskii_kray66 = document.querySelectorAll('.PERMSKII_KRAY66')
let Primorskii_kray67 = document.querySelectorAll('.PRIMORSKII_KRAY67')
let Stavropolskii68 = document.querySelectorAll('.STAVROPOLSKII68')
let Habarovskii_kray69 = document.querySelectorAll('.HABAROVSKII_KRAY69')
// let other = document.querySelectorAll('.other')


function SizeDisplay(listCity){
    console.log(listCity)
    container_info_gl.classList.add('open')
    name_city.innerHTML = listCity.name
    info_city.innerHTML = listCity.info
}
function getInfoCity(nameCity){
    for(let i = 0; i < cities.length; i++){
        if(cities[i].id == nameCity){
            console.log(cities[i].id)
            SizeDisplay(cities[i])
        }
    }
}

$('#close_display_search').click(function(){
    container_trey.classList.add('close');
})
$('#open_display_search').click(function(){
    // container_trey.style.display = 'flex'
    container_trey.classList.remove('close')
    container_trey.classList.add('open');
    // $(container_trey).on('transitionend',function(){
    // })
})
$(close_display_info).click(function(){
    container_info_gl.classList.remove('open')
})

// Krosnayarsk___________________________________________
for(let i = 0; i < Krosnoyarsk.length; i++){
    $(Krosnoyarsk[i]).click(function(){
        getInfoCity('Krosnoyarsk')
    })
}
// Yakutia_______________________________________________
for(let i = 0; i < Yakutia.length; i++){
    $(Yakutia[i]).click(function(){
        getInfoCity('Yakutia')
    })
}
// Chukotka_______________________________________________
for(let i = 0; i < Chukotka.length; i++){
    $(Chukotka[i]).click(function(){
        getInfoCity('Chukotka')
    })
}
// Yamalonenezkii_ao_______________________________________________
for(let i = 0; i < Yamalonenezkii_ao.length; i++){
    $(Yamalonenezkii_ao[i]).click(function(){
        getInfoCity('Yamalonenezkii_ao')
    })
}
// Hantamansiiskiy_ao_______________________________________________
for(let i = 0; i < Hantamansiiskiy_ao.length; i++){
    $(Hantamansiiskiy_ao[i]).click(function(){
        getInfoCity('Hantamansiiskiy_ao')
    })
}
// Irkutsk_______________________________________________
for(let i = 0; i < Irkutsk.length; i++){
    $(Irkutsk[i]).click(function(){
        getInfoCity('Irkutsk')
    })
}
// Amurskay_oblast_______________________________________________
for(let i = 0; i < Amurskay_oblast.length; i++){
    $(Amurskay_oblast[i]).click(function(){
        getInfoCity('Amurskay_oblast')
    })
}
// Komi_______________________________________________
for(let i = 0; i < Komi.length; i++){
    $(Komi[i]).click(function(){
        getInfoCity('Komi')
    })
}
// Tayava_______________________________________________
for(let i = 0; i < Tayava.length; i++){
    $(Tayava[i]).click(function(){
        getInfoCity('Tayava')
    })
}
// Altay_______________________________________________
for(let i = 0; i < Altay.length; i++){
    $(Altay[i]).click(function(){
        getInfoCity('Altay')
    })
}
// Tomskay_oblast_______________________________________________
for(let i = 0; i < Tomskay_oblast.length; i++){
    $(Tomskay_oblast[i]).click(function(){
        getInfoCity('Tomskay_oblast')
    })
}
// Altaiskii_kray62_______________________________________________
for(let i = 0; i < Altaiskii_kray62.length; i++){
    $(Altaiskii_kray62[i]).click(function(){
        getInfoCity('Altaiskii_kray62')
    })
}
// Arhangelskay_oblast1 _______________________________________________
for(let i = 0; i < Arhangelskay_oblast1.length; i++){
    $(Arhangelskay_oblast1[i]).click(function(){
        getInfoCity('Arhangelskay_oblast1')
    })
}
// Astrahanskay_oblast2 _______________________________________________
for(let i = 0; i < Astrahanskay_oblast2.length; i++){
    $(Astrahanskay_oblast2[i]).click(function(){
        getInfoCity('Astrahanskay_oblast2')
    })
}
// Belgorodskay_oblast3 _______________________________________________
for(let i = 0; i < Belgorodskay_oblast3.length; i++){
    $(Belgorodskay_oblast3[i]).click(function(){
        getInfoCity('Belgorodskay_oblast3')
    })
}
// Branskay_oblast4 _______________________________________________
for(let i = 0; i < Branskay_oblast4.length; i++){
    $(Branskay_oblast4[i]).click(function(){
        getInfoCity('Branskay_oblast4')
    })
}
// Vladimirskay5 _______________________________________________
for(let i = 0; i < Vladimirskay5.length; i++){
    $(Vladimirskay5[i]).click(function(){
        getInfoCity('Vladimirskay5')
    })
}
// Volgogradsay_oblast6 _______________________________________________
for(let i = 0; i < Volgogradsay_oblast6.length; i++){
    $(Volgogradsay_oblast6[i]).click(function(){
        getInfoCity('Volgogradsay_oblast6')
    })
}
// Vologodskay_oblast7 _______________________________________________
for(let i = 0; i < Vologodskay_oblast7.length; i++){
    $(Vologodskay_oblast7[i]).click(function(){
        getInfoCity('Vologodskay_oblast7')
    })
}
// Voronechskay_oblast8 _______________________________________________
for(let i = 0; i < Voronechskay_oblast8.length; i++){
    $(Voronechskay_oblast8[i]).click(function(){
        getInfoCity('Voronechskay_oblast8')
    })
}
// Ivanovskay_oblast9 _______________________________________________
for(let i = 0; i < Ivanovskay_oblast9.length; i++){
    $(Ivanovskay_oblast9[i]).click(function(){
        getInfoCity('Ivanovskay_oblast9')
    })
}
// Kaliningradskay_oblast10 _______________________________________________
for(let i = 0; i < Kaliningradskay_oblast10.length; i++){
    $(Kaliningradskay_oblast10[i]).click(function(){
        getInfoCity('Kaliningradskay_oblast10')
    })
}
// Kalurchskay11 _______________________________________________
for(let i = 0; i < Kalurchskay11.length; i++){
    $(Kalurchskay11[i]).click(function(){
        getInfoCity('Kalurchskay11')
    })
}
// Kemerovskay_oblast12 _______________________________________________
for(let i = 0; i < Kemerovskay_oblast12.length; i++){
    $(Kemerovskay_oblast12[i]).click(function(){
        getInfoCity('Kemerovskay_oblast12')
    })
}
// Kurganskay_oblast13 _______________________________________________
for(let i = 0; i < Kurganskay_oblast13.length; i++){
    $(Kurganskay_oblast13[i]).click(function(){
        getInfoCity('Kurganskay_oblast13')
    })
}
// kostromskay_oblast14 _______________________________________________
for(let i = 0; i < kostromskay_oblast14.length; i++){
    $(kostromskay_oblast14[i]).click(function(){
        getInfoCity('kostromskay_oblast14')
    })
}
// Kurganskay_oblast15 _______________________________________________
for(let i = 0; i < Kurganskay_oblast15.length; i++){
    $(Kurganskay_oblast15[i]).click(function(){
        getInfoCity('Kurganskay_oblast15')
    })
}
// Leningradskay_oblast17 _______________________________________________
for(let i = 0; i < Leningradskay_oblast17.length; i++){
    $(Leningradskay_oblast17[i]).click(function(){
        getInfoCity('Leningradskay_oblast17')
    })
}
// Lipezkay_oblast18 _______________________________________________
for(let i = 0; i < Lipezkay_oblast18.length; i++){
    $(Lipezkay_oblast18[i]).click(function(){
        getInfoCity('Lipezkay_oblast18')
    })
}
// Magadanskay_oblast19 _______________________________________________
for(let i = 0; i < Magadanskay_oblast19.length; i++){
    $(Magadanskay_oblast19[i]).click(function(){
        getInfoCity('Magadanskay_oblast19')
    })
}
// Moskovskay_oblast20 _______________________________________________
for(let i = 0; i < Moskovskay_oblast20.length; i++){
    $(Moskovskay_oblast20[i]).click(function(){
        getInfoCity('Moskovskay_oblast20')
    })
}
// Murmanskay_oblast21 _______________________________________________
for(let i = 0; i < Murmanskay_oblast21.length; i++){
    $(Murmanskay_oblast21[i]).click(function(){
        getInfoCity('Murmanskay_oblast21')
    })
}
// Nichegorodskay_oblast22 _______________________________________________
for(let i = 0; i < Nichegorodskay_oblast22.length; i++){
    $(Nichegorodskay_oblast22[i]).click(function(){
        getInfoCity('Nichegorodskay_oblast22')
    })
}
// Novgorodskay_oblast23 _______________________________________________
for(let i = 0; i < Novgorodskay_oblast23.length; i++){
    $(Novgorodskay_oblast23[i]).click(function(){
        getInfoCity('Novgorodskay_oblast23')
    })
}
// Omskay_oblast24 _______________________________________________
for(let i = 0; i < Omskay_oblast24.length; i++){
    $(Omskay_oblast24[i]).click(function(){
        getInfoCity('Omskay_oblast24')
    })
}
// Novosibirskay_oblast25 _______________________________________________
for(let i = 0; i < Novosibirskay_oblast25.length; i++){
    $(Novosibirskay_oblast25[i]).click(function(){
        getInfoCity('Novosibirskay_oblast25')
    })
}
// Orenburgskay_oblast26 _______________________________________________
for(let i = 0; i < Orenburgskay_oblast26.length; i++){
    $(Orenburgskay_oblast26[i]).click(function(){
        getInfoCity('Orenburgskay_oblast26')
    })
}
// Orlovskay_oblast27 _______________________________________________
for(let i = 0; i < Orlovskay_oblast27.length; i++){
    $(Orlovskay_oblast27[i]).click(function(){
        getInfoCity('Orlovskay_oblast27')
    })
}
// Penzenskay_oblast28 _______________________________________________
for(let i = 0; i < Penzenskay_oblast28.length; i++){
    $(Penzenskay_oblast28[i]).click(function(){
        getInfoCity('Penzenskay_oblast28')
    })
}
// Pskovskay_oblast29 _______________________________________________
for(let i = 0; i < Pskovskay_oblast29.length; i++){
    $(Pskovskay_oblast29[i]).click(function(){
        getInfoCity('Pskovskay_oblast29')
    })
}
// Rostovskay_oblast30 _______________________________________________
for(let i = 0; i < Rostovskay_oblast30.length; i++){
    $(Rostovskay_oblast30[i]).click(function(){
        getInfoCity('Rostovskay_oblast30')
    })
}
// Ryzanskay_oblast31 _______________________________________________
for(let i = 0; i < Ryzanskay_oblast31.length; i++){
    $(Ryzanskay_oblast31[i]).click(function(){
        getInfoCity('Ryzanskay_oblast31')
    })
}
// Samarskay_oblast32 _______________________________________________
for(let i = 0; i < Samarskay_oblast32.length; i++){
    $(Samarskay_oblast32[i]).click(function(){
        getInfoCity('Samarskay_oblast32')
    })
}
// Saratovskay_oblast33 _______________________________________________
for(let i = 0; i < Saratovskay_oblast33.length; i++){
    $(Saratovskay_oblast33[i]).click(function(){
        getInfoCity('Saratovskay_oblast33')
    })
}
// Sahalinskay_oblast34 _______________________________________________
for(let i = 0; i < Sahalinskay_oblast34.length; i++){
    $(Sahalinskay_oblast34[i]).click(function(){
        getInfoCity('Sahalinskay_oblast34')
    })
}
// Sverdlovskay_oblast35 _______________________________________________
for(let i = 0; i < Sverdlovskay_oblast35.length; i++){
    $(Sverdlovskay_oblast35[i]).click(function(){
        getInfoCity('Sverdlovskay_oblast35')
    })
}
// Smolenskay_oblast36 _______________________________________________
for(let i = 0; i < Smolenskay_oblast36.length; i++){
    $(Smolenskay_oblast36[i]).click(function(){
        getInfoCity('Smolenskay_oblast36')
    })
}
// Tambovskay_oblast37 _______________________________________________
for(let i = 0; i < Tambovskay_oblast37.length; i++){
    $(Tambovskay_oblast37[i]).click(function(){
        getInfoCity('Tambovskay_oblast37')
    })
}
// Tverskay_oblast38 _______________________________________________
for(let i = 0; i < Tverskay_oblast38.length; i++){
    $(Tverskay_oblast38[i]).click(function(){
        getInfoCity('Tverskay_oblast38')
    })
}
// Tulskay_oblast39 _______________________________________________
for(let i = 0; i < Tulskay_oblast39.length; i++){
    $(Tulskay_oblast39[i]).click(function(){
        getInfoCity('Tulskay_oblast39')
    })
}
// Tymenskay_oblast40 _______________________________________________
for(let i = 0; i < Tymenskay_oblast40.length; i++){
    $(Tymenskay_oblast40[i]).click(function(){
        getInfoCity('Tymenskay_oblast40')
    })
}
// Ulaynovskay_oblast41 _______________________________________________
for(let i = 0; i < Ulaynovskay_oblast41.length; i++){
    $(Ulaynovskay_oblast41[i]).click(function(){
        getInfoCity('Ulaynovskay_oblast41')
    })
}
// Chelybinskay_oblast42 _______________________________________________
for(let i = 0; i < Chelybinskay_oblast42.length; i++){
    $(Chelybinskay_oblast42[i]).click(function(){
        getInfoCity('Chelybinskay_oblast42')
    })
}
// Yaroslavskay_oblast43 _______________________________________________
for(let i = 0; i < Yaroslavskay_oblast43.length; i++){
    $(Yaroslavskay_oblast43[i]).click(function(){
        getInfoCity('Yaroslavskay_oblast43')
    })
}// Adageya44 _______________________________________________
for(let i = 0; i < Adageya44.length; i++){
    $(Adageya44[i]).click(function(){
        getInfoCity('Adageya44')
    })
}
// Bashkortostan45 _______________________________________________
for(let i = 0; i < Bashkortostan45.length; i++){
    $(Bashkortostan45[i]).click(function(){
        getInfoCity('Bashkortostan45')
    })
}
// Burytiay46 _______________________________________________
for(let i = 0; i < Burytiay46.length; i++){
    $(Burytiay46[i]).click(function(){
        getInfoCity('Burytiay46')
    })
}
// Dagestan47 _______________________________________________
for(let i = 0; i < Dagestan47.length; i++){
    $(Dagestan47[i]).click(function(){
        getInfoCity('Dagestan47')
    })
}
// Ingushetia48 _______________________________________________
for(let i = 0; i < Ingushetia48.length; i++){
    $(Ingushetia48[i]).click(function(){
        getInfoCity('Ingushetia48')
    })
}
// Kabardino49 _______________________________________________
for(let i = 0; i < Kabardino49.length; i++){
    $(Kabardino49[i]).click(function(){
        getInfoCity('Kabardino49')
    })
}
// Kalmkiy50 _______________________________________________
for(let i = 0; i < Kalmkiy50.length; i++){
    $(Kalmkiy50[i]).click(function(){
        getInfoCity('Kalmkiy50')
    })
}
// Karachaevo51 _______________________________________________
for(let i = 0; i < Karachaevo51.length; i++){
    $(Karachaevo51[i]).click(function(){
        getInfoCity('Karachaevo51')
    })
}
// Kaleriy52 _______________________________________________
for(let i = 0; i < Kaleriy52.length; i++){
    $(Kaleriy52[i]).click(function(){
        getInfoCity('Kaleriy52')
    })
}
// Krym53 _______________________________________________
for(let i = 0; i < Krym53.length; i++){
    $(Krym53[i]).click(function(){
        getInfoCity('Krym53')
    })
}
// mariiyal54 _______________________________________________
for(let i = 0; i < mariiyal54.length; i++){
    $(mariiyal54[i]).click(function(){
        getInfoCity('mariiyal54')
    })
}
// mordoviy55 _______________________________________________
for(let i = 0; i < mordoviy55.length; i++){
    $(mordoviy55[i]).click(function(){
        getInfoCity('mordoviy55')
    })
}
// Osetiay56 _______________________________________________
for(let i = 0; i < Osetiay56.length; i++){
    $(Osetiay56[i]).click(function(){
        getInfoCity('Osetiay56')
    })
}
// Udmurtskay58 _______________________________________________
for(let i = 0; i < Udmurtskay58.length; i++){
    $(Udmurtskay58[i]).click(function(){
        getInfoCity('Udmurtskay58')
    })
}
// Hakasiy59 _______________________________________________
for(let i = 0; i < Hakasiy59.length; i++){
    $(Hakasiy59[i]).click(function(){
        getInfoCity('Hakasiy59')
    })
}
// Chuvashskay60 _______________________________________________
for(let i = 0; i < Chuvashskay60.length; i++){
    $(Chuvashskay60[i]).click(function(){
        getInfoCity('Chuvashskay60')
    })
}
// Evreiskay_avtonomnay_oblast61 _______________________________________________
for(let i = 0; i < Evreiskay_avtonomnay_oblast61.length; i++){
    $(Evreiskay_avtonomnay_oblast61[i]).click(function(){
        getInfoCity('Evreiskay_avtonomnay_oblast61')
    })
}
// Nenezkii_ao62 _______________________________________________
for(let i = 0; i < Nenezkii_ao62.length; i++){
    $(Nenezkii_ao62[i]).click(function(){
        getInfoCity('Nenezkii_ao62')
    })
}
// Sevastopol63 _______________________________________________
for(let i = 0; i < Sevastopol63.length; i++){
    $(Sevastopol63[i]).click(function(){
        getInfoCity('Sevastopol63')
    })
}
// Kamchatskii_kray64 _______________________________________________
for(let i = 0; i < Kamchatskii_kray64.length; i++){
    $(Kamchatskii_kray64[i]).click(function(){
        getInfoCity('Kamchatskii_kray64')
    })
}
// Krasnodarskii65 _______________________________________________
for(let i = 0; i < Krasnodarskii65.length; i++){
    $(Krasnodarskii65[i]).click(function(){
        getInfoCity('Krasnodarskii65')
    })
}
// Permskii_kray66 _______________________________________________
for(let i = 0; i < Permskii_kray66.length; i++){
    $(Permskii_kray66[i]).click(function(){
        getInfoCity('Permskii_kray66')
    })
}
// Primorskii_kray67 _______________________________________________
for(let i = 0; i < Primorskii_kray67.length; i++){
    $(Primorskii_kray67[i]).click(function(){
        getInfoCity('Primorskii_kray67')
    })
}
// Stavropolskii68 _______________________________________________
for(let i = 0; i < Stavropolskii68.length; i++){
    $(Stavropolskii68[i]).click(function(){
        getInfoCity('Stavropolskii68')
    })
}
// Habarovskii_kray69 _______________________________________________
for(let i = 0; i < Habarovskii_kray69.length; i++){
    $(Habarovskii_kray69[i]).click(function(){
        getInfoCity('Habarovskii_kray69')
    })
}
